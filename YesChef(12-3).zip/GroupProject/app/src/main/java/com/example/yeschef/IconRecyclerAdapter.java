package com.example.yeschef;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class IconRecyclerAdapter extends RecyclerView.Adapter<IconRecyclerAdapter.IconRecyclerViewHolder>{
    boolean check = true;
    boolean select = true;

    private ArrayList<IconRecyclerModel> items;
    int row_index = 0;

    public IconRecyclerAdapter(ArrayList<IconRecyclerModel> items) {
        this.items = items;
    }

    @NonNull
    @Override
    public IconRecyclerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.icon_recycler_item, parent, false);
        IconRecyclerViewHolder iconRecyclerViewHolder = new IconRecyclerViewHolder(view);
        return  iconRecyclerViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull IconRecyclerViewHolder holder, int position) {
        IconRecyclerModel currentItem = items.get(position);
        holder.imageView.setImageResource(currentItem.getImage());
        holder.textView.setText(currentItem.getText());

        holder.linearLayout.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                row_index = position;
                notifyDataSetChanged();
            }
        });

        if (row_index == position) {
            holder.linearLayout.setBackgroundResource(R.drawable.icon_recycler_bg_selected);
        } else {
            holder.linearLayout.setBackgroundResource(R.drawable.icon_recycler_bg);
        }
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    public static class IconRecyclerViewHolder extends RecyclerView.ViewHolder{

        TextView textView;
        ImageView imageView;
        LinearLayout linearLayout;

        public IconRecyclerViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.categoryImage);
            textView = itemView.findViewById(R.id.categoryText);
            linearLayout = itemView.findViewById(R.id.linearLayout);
        }
    }

}
