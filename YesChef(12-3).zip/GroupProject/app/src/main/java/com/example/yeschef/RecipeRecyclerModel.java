package com.example.yeschef;

import android.graphics.Bitmap;

public class RecipeRecyclerModel {

    private String name;
    private Bitmap image;
    private String link;
    private String saved;

    //String imageLink, String link, String saved
    public RecipeRecyclerModel(String name, Bitmap image){
        this.name = name;
        this.image = image;
//        this.link = link;
    }

    public String getName(){
        return name;
    }

    public Bitmap getImageLink(){
        return image;
    }

//    public String getLink(){
//        return link;
//    }
//
//    public String getSaved(){
//        return saved;
//    }
}
