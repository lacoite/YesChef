package com.example.yeschef;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class CookbookActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cookbook);
    }

    public void onClickRecipeImage(View view){
        CharSequence text = "Clicking on this image will take the user to a preview of the online recipe! The user can then navigate to the original recipe online.";
        int duration = Toast.LENGTH_LONG;
        Toast toast = Toast.makeText(this, text, duration);
        toast.show();
    }
    public void onClickRecipeFavorite(View view){
        CharSequence text = "Clicking on this icon will remove the respective recipe from the user's cookbook!";
        int duration = Toast.LENGTH_LONG;
        Toast toast = Toast.makeText(this, text, duration);
        toast.show();
    }

    public void onClickRecipes(View view){
        Intent intent = new Intent(CookbookActivity.this, RecipesActivity.class);
        startActivity(intent);
    }

    public void onClickPantry(View view){
        Intent intent = new Intent(CookbookActivity.this, PantryActivity.class);
        startActivity(intent);
    }

    public void onClickMealPlan(View view){
        Intent intent = new Intent(CookbookActivity.this, MealPlanActivity.class);
        startActivity(intent);
    }


}