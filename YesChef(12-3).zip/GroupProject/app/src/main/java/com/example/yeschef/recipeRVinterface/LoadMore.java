package com.example.yeschef.recipeRVinterface;

public interface LoadMore {
    void onLoadMore();
}
