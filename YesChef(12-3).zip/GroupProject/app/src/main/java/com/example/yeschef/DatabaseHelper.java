package com.example.yeschef;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {
    Context context;
    SQLiteDatabase db;
    //Database Version
    private static final int DATABASE_VERSION = 1;

    //Database Path and User

    public static String DB_PATH = "/data/data/com.example.yeschef/databases/";
    public static final String TB_USER = "Users";

    //Database name
    private static final String DATABASE_NAME = "YesChef_db_original.db";

    //Table names
    public static final String INGREDIENTS_TABLE_NAME = "Ingredients";
    public static final String SAVED_TABLE_NAME = "Saved";
    public static final String MEAL_TABLE_NAME = "Meals";

    //Ingredient Table Columns
    public static final String INGREDIENT_COLUMN = "Ingredient";
    public static final String SELECTED_COLUMN = "Selected";
    public static final String TYPE_COLUMN = "Type";

    //Saved Table Columns
    public static final String ID_COLUMN = "Id";

    //Create table SQL Query
    public static final String CREATE_INGREDIENTS_TABLE = "CREATE TABLE " +
            INGREDIENTS_TABLE_NAME + "(" + INGREDIENT_COLUMN + " TEXT, " + SELECTED_COLUMN + " TEXT, " + TYPE_COLUMN +
            " TEXT )";

    public static final String CREATE_SAVED_TABLE = "CREATE TABLE " + SAVED_TABLE_NAME + " TEXT, " + ID_COLUMN + " TEXT, ";

    //closes connections
    @Override
    public synchronized void close() {
        if(db != null)
            db.close();
        super.close();
    }

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    //Open
    public void openDataBase() throws SQLException {
        String myPath = DB_PATH + DATABASE_NAME;
        SQLiteDatabase db = SQLiteDatabase.openDatabase(myPath, null, SQLiteDatabase.OPEN_READWRITE);
    }

    //Check v2
    public boolean checkDataBase(){
        File databaseFile = new File(DB_PATH + DATABASE_NAME);
        return databaseFile.exists();
    }

    //Copy
    public void copyDataBase() throws IOException {
        try {
            InputStream myInput = context.getAssets().open(DATABASE_NAME);
            String outputFileName = DB_PATH + DATABASE_NAME;
            OutputStream myOutput = new FileOutputStream(outputFileName);

            byte[] buffer = new byte[1024];
            int length;

            while((length = myInput.read(buffer))>0){
                myOutput.write(buffer, 0, length);
            }

            myOutput.flush();
            myOutput.close();
            myInput.close();
        } catch (Exception e) {
            Log.e("tle99 - copyDatabase", e.getMessage());
        }

    }

    public void createDataBase() throws IOException {
        boolean dbExist = checkDataBase();

        if (dbExist) {

        } else {
            this.getReadableDatabase();
            try {
                copyDataBase();
            } catch (IOException e) {
                Log.e("tle99 - create", e.getMessage());
            }
        }
    }

    // Creating tables
    @Override
    public void onCreate(SQLiteDatabase db){
        //no code needed for Indgredients db, may need for other tables
    }

    //Updating Database
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
        // No code needed for Indgredients db, may need for other tables

    }

    //Update Checkbox
    public void updateCheckbox(String ingredient, String checkedState) {
        // get writable database as we want to write data
        Log.i("HERE: ", "IN DB CLASS");
        SQLiteDatabase db = this.getWritableDatabase();
        Log.i("STEP: ", "Writable");

        Log.i("STEP: ", "contentValues");

        ContentValues values = new ContentValues();
        values.put(SELECTED_COLUMN, checkedState);

        Log.i("STEP: ", "Update");
        db.update(INGREDIENTS_TABLE_NAME, values, "Ingredient = \"" + ingredient + "\"", null);


        // close db connection
        db.close();
    }

    //Clearing Saved Table
    public void clearSaved() {
        // get writable database as we want to write data
        SQLiteDatabase db = this.getWritableDatabase();

        //if Saved_Table exists, drop it and recreate empty, OR delete all records from table

        // close db connection
        db.close();
    }

    //Resetting Selected Values
    public void resetSelected(String category) {
        // get writable database as we want to write data
        Log.i("HERE: ", "IN DB CLASS FRO RESET");
        SQLiteDatabase db = this.getWritableDatabase();
        Log.i("STEP: ", "Writable");

        Log.i("STEP: ", "contentValues");
        ContentValues values = new ContentValues();
        values.put(SELECTED_COLUMN, "false");

        Log.i("STEP: ", "Update");
        try {
            if (category == "all") {
                db.update(INGREDIENTS_TABLE_NAME, values, "Selected = \"true\"", null);
            } else {
                db.update(INGREDIENTS_TABLE_NAME, values, "Type = \"" + category + "\"", null);
            }
        }
        catch (Exception e){
            db.close();
        }

        // close db connection
        db.close();
    }

    //Ingredient by Type
    public List<IngredientRecyclerModel> getIngredientsByType(String ingredientType) {
        List<IngredientRecyclerModel> ingredients_of_type = new ArrayList<>();

        //Select All Where Selected Is True
        String selectQuery = "SELECT * FROM " + INGREDIENTS_TABLE_NAME; //+ " WHERE " + TYPE_COLUMN + " = \"" + ingredientType + "\"";
        //SQLiteDatabase db = this.getWritableDatabase();
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        //Looping through all selected rows and adding to list
        if(cursor.moveToFirst()){
            do{
                String ingredientSelected = cursor.getString(cursor.getColumnIndexOrThrow(INGREDIENT_COLUMN));
                String selectedState = cursor.getString(cursor.getColumnIndexOrThrow(SELECTED_COLUMN));
                String typeState = cursor.getString(cursor.getColumnIndexOrThrow(TYPE_COLUMN));
                Log.i("ROW: ", ingredientSelected + selectedState + typeState);
                ingredients_of_type.add(new IngredientRecyclerModel(ingredientSelected, selectedState, typeState));

            }while(cursor.moveToNext());
        }

        //Close db connection
        db.close();
        Log.i("IN FUNCTION: ", "DB CLOSED");

        return ingredients_of_type;
    }


    //Get list of selected ingredients, Peyton, you'll need to save it to a string/array for the API call! -Latasha
    public List<IngredientRecyclerModel> getSelectedIngredients() {
        List<IngredientRecyclerModel> selected_ingredients = new ArrayList<>();

        //Select All Where Selected Is True
        String selectQuery = "SELECT * FROM " + INGREDIENTS_TABLE_NAME + " WHERE " + SELECTED_COLUMN + " = \"true\"";
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        Log.d("MESSAGE: ",selectQuery);

        //Looping through all selected rows and adding to list
        Boolean b = cursor.moveToFirst();
        Log.d("MESSAGE: ", String.valueOf(b));

        if(cursor.moveToFirst()){
            do{
                String ingredientSelected = cursor.getString(cursor.getColumnIndexOrThrow(INGREDIENT_COLUMN));
                String selectedState = cursor.getString(cursor.getColumnIndexOrThrow(SELECTED_COLUMN));
                String typeState = cursor.getString(cursor.getColumnIndexOrThrow(TYPE_COLUMN));
                selected_ingredients.add(new IngredientRecyclerModel(ingredientSelected, selectedState, typeState));

                //Log.d("MESSAGE: ", ingredientSelected + selectedState + typeState);
            }while(cursor.moveToNext());
        }

        //Close db connection
        db.close();

        return selected_ingredients;
    }

    //Is this where these methods need to be?
    //Is this how you actually implement insert/delete anyway?? idr
    public void insert(String savedTableName, Object o, ContentValues values) {
    }

    public void delete(String savedTableName, String s, String[] strings) {
    }
}
