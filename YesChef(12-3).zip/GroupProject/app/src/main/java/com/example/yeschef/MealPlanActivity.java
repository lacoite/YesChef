package com.example.yeschef;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MealPlanActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_meal_plan);
    }

    public void onClickMealPlanImage(View view) {
        CharSequence text = "Clicking on this image will take user to online recipe";
        int duration = Toast.LENGTH_LONG;
        Toast toast = Toast.makeText(this, text, duration);
        toast.show();
    }

    public void onClickMealPlanEdit(View view) {
        CharSequence text = "Clicking on this image will take user to menu to edit weekly recipes";
        int duration = Toast.LENGTH_LONG;
        Toast toast = Toast.makeText(this, text, duration);
        toast.show();
    }

    public void onClickRecipes(View view){
        Intent intent = new Intent(MealPlanActivity.this, RecipesActivity.class);
        startActivity(intent);
    }

    public void onClickPantry(View view){
        Intent intent = new Intent(MealPlanActivity.this, PantryActivity.class);
        startActivity(intent);
    }

    public void onClickCookBook(View view){
        Intent intent = new Intent(MealPlanActivity.this, CookbookActivity.class);
        startActivity(intent);
    }
}