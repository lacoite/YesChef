public class Meal {
}
